package com.ye.healthDataEndpoint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataDownloadEndpointApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataDownloadEndpointApplication.class, args);
	}
}
